set head off feed off
select count(*) from dba_users where username='ORDS_PUBLIC_USER';
exit
